#!/usr/bin/env python3

def say_hello():
    print('Welcome to the Brain Games!')


def main():
    say_hello()


if __name__ == '__main__':
    main()
